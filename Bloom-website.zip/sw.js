/* Generated from this template by scripts/pwa.mjs. Do not register the raw
   development copy: only production builds contain the complete asset list. */
const VERSION = 'ae9823ebd17d0a441b0d';
const PRECACHE = ["/404.html","/about/index.html","/assets/App-BAkQJ_BH.js","/assets/App-BEnu8-US.css","/assets/InfoPages-1G9f0kSY.js","/assets/dm-sans-latin-400-normal-BwCSEQnW.woff","/assets/dm-sans-latin-400-normal-CW0RaeGs.woff2","/assets/dm-sans-latin-500-normal-B9HHJjqV.woff2","/assets/dm-sans-latin-500-normal-Dr3UlScf.woff","/assets/dm-sans-latin-600-normal-Aqo67rzb.woff2","/assets/dm-sans-latin-600-normal-BmdmIIQ2.woff","/assets/dm-sans-latin-700-normal-CUSSCpQX.woff","/assets/dm-sans-latin-700-normal-DvUfVpUG.woff2","/assets/dm-serif-display-latin-400-italic-BgxzcTJK.woff","/assets/dm-serif-display-latin-400-italic-DpcbibHm.woff2","/assets/dm-serif-display-latin-400-normal-C5_t9oOD.woff2","/assets/dm-serif-display-latin-400-normal-_kVFYEpx.woff","/assets/index-DjPkaVdr.js","/assets/index-EDPKswfQ.css","/bloom-social.png","/bloom-social.svg","/contact/index.html","/favicon.svg","/games/bloom/index.html","/garden.svg","/icons/apple-touch-icon.png","/icons/bloom-192.png","/icons/bloom-512.png","/icons/bloom-maskable-512.png","/icons/bloom-maskable.svg","/icons/bloom.svg","/index.html","/manifest.webmanifest","/offline.html","/privacy/index.html"];
const PREFIX = 'bloom-static-v1-';
const CACHE_NAME = `${PREFIX}${VERSION}`;
const METADATA_URL = new URL('/.bloom-cache-metadata', self.location.origin).href;
const STATIC_URLS = new Set(PRECACHE.map(path => new URL(path, self.location.origin).href));
const DOCUMENTS = new Map([
  ['/', '/index.html'],
  ['/games/bloom', '/games/bloom/index.html'],
  ['/about', '/about/index.html'],
  ['/privacy', '/privacy/index.html'],
  ['/contact', '/contact/index.html'],
]);
const clientVersions = new Map();

function isPublicResponse(response, path) {
  if (!response.ok || !['basic', 'default'].includes(response.type)) return false;
  if (new URL(response.url || path, self.location.origin).origin !== self.location.origin) return false;
  if (/\b(?:private|no-store)\b/i.test(response.headers.get('cache-control') || '')) return false;
  if (/\bcookie\b/i.test(response.headers.get('vary') || '') || response.headers.has('set-cookie')) return false;
  const type = response.headers.get('content-type') || '';
  if (/\.html$/.test(path)) return /\btext\/html\b/i.test(type);
  if (/\.js$/.test(path)) return /(?:javascript|ecmascript)/i.test(type);
  if (/\.css$/.test(path)) return /\btext\/css\b/i.test(type);
  return true;
}

async function cacheMetadata(cache) {
  try {
    const response = await cache.match(METADATA_URL);
    const value = response && await response.json();
    return value && Number.isFinite(value.createdAt) ? value : null;
  } catch { return null; }
}

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    if (!/^[a-f0-9]{20}$/.test(VERSION) || PRECACHE.length === 0) throw new Error('Incomplete Bloom offline build.');
    const cache = await caches.open(CACHE_NAME);
    const existed = Boolean(await cacheMetadata(cache));
    try {
      await Promise.all(PRECACHE.map(async path => {
        // Public shell requests never carry login cookies. Private APIs and
        // third-party resources are absent from the build's allowlist.
        const response = await fetch(new Request(path, { credentials: 'omit', cache: 'reload' }));
        if (!isPublicResponse(response, path)) throw new Error(`Cannot prepare offline asset: ${path}`);
        if (/\.html$/.test(path)) {
          const html = await response.clone().text();
          const pageVersion = html.match(/<meta\s+name=["']bloom-build["']\s+content=["']([a-f0-9]{20})["']/i)?.[1];
          if (pageVersion !== VERSION) throw new Error(`The deployment changed while preparing ${path}. Try the complete new build instead.`);
        }
        await cache.put(path, response);
      }));
      await cache.put(METADATA_URL, new Response(JSON.stringify({ version: VERSION, createdAt: Date.now() }), { headers: { 'content-type': 'application/json' } }));
    } catch (error) {
      if (!existed) await caches.delete(CACHE_NAME);
      throw error;
    }
    // Updates wait until the player explicitly chooses Refresh in the page.
    // No skipWaiting here: an active puzzle is never interrupted automatically.
  })());
});

async function reportVersionRequests() {
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  for (const client of clients) client.postMessage({ type: 'BLOOM_REPORT_CLIENT_VERSION' });
}

async function pruneUnusedVersions() {
  const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  // An old tab may still need a lazy-loaded game chunk. Keep every old cache
  // until all open clients have identified the build their HTML belongs to.
  if (clients.some(client => !clientVersions.has(client.id))) return;
  const protectedVersions = new Set([VERSION, ...clients.map(client => clientVersions.get(client.id))]);
  const currentMetadata = await cacheMetadata(await caches.open(CACHE_NAME));
  if (!currentMetadata) return;
  for (const name of await caches.keys()) {
    if (!name.startsWith(PREFIX) || protectedVersions.has(name.slice(PREFIX.length))) continue;
    const metadata = await cacheMetadata(await caches.open(name));
    // A newer cache may belong to a waiting update. An older active worker
    // must never delete that update's completed offline installation.
    if (metadata && metadata.createdAt < currentMetadata.createdAt) await caches.delete(name);
  }
}

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    await self.clients.claim();
    await reportVersionRequests();
  })());
});

self.addEventListener('message', event => {
  if (!event.source || !event.source.id || new URL(event.source.url).origin !== self.location.origin) return;
  if (event.data?.type === 'SKIP_WAITING') {
    event.waitUntil(self.skipWaiting());
  } else if (event.data?.type === 'BLOOM_CLIENT_VERSION' && /^[a-f0-9]{20}$/.test(event.data.version)) {
    clientVersions.set(event.source.id, event.data.version);
    event.waitUntil(pruneUnusedVersions());
  }
});

async function cachedStatic(request) {
  const current = await caches.open(CACHE_NAME);
  const own = await current.match(request);
  if (own) return own;
  // Keep previous-version chunks available to other open tabs after an update.
  for (const name of await caches.keys()) {
    if (name === CACHE_NAME || !name.startsWith(PREFIX)) continue;
    const previous = await (await caches.open(name)).match(request);
    if (previous) return previous;
  }
  return fetch(request); // Unknown/static-later resources are never cached.
}

async function documentResponse(request, url) {
  try {
    const response = await fetch(request);
    if (response.ok || response.status === 404) return response;
  } catch { /* An installed, complete public shell is available below. */ }
  const path = url.pathname.replace(/\/index\.html$/, '').replace(/\/+$/, '') || '/';
  const document = DOCUMENTS.get(path);
  const cache = await caches.open(CACHE_NAME);
  if (document) {
    const response = await cache.match(document);
    if (response) return response;
  }
  return await cache.match('/offline.html') || new Response('Reconnect to open this page.', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } });
}

self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  // No account, score, session, authentication, analytics, or other dynamic
  // response ever enters a cache, regardless of its response headers.
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname === '/api' || url.pathname.startsWith('/api/')) return;
  if (request.mode === 'navigate') {
    event.respondWith(documentResponse(request, url));
    return;
  }
  if (url.search || url.hash) return;
  if (STATIC_URLS.has(url.href) || /^\/assets\/[^/]+\.(?:js|css|woff2?|ttf|otf|png|jpe?g|webp|svg|avif)$/.test(url.pathname)) event.respondWith(cachedStatic(request));
});
